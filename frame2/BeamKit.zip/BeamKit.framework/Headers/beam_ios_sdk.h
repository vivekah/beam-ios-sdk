//
//  beam_ios_sdk.h
//  beam-ios-sdk
//
//  Created by ALEXANDRA SALVATORE on 6/26/19.
//  Copyright © 2019 Beam Impact. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for beam_ios_sdk.
FOUNDATION_EXPORT double beam_ios_sdkVersionNumber;

//! Project version string for beam_ios_sdk.
FOUNDATION_EXPORT const unsigned char beam_ios_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <beam_ios_sdk/PublicHeader.h>


